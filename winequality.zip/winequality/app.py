from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score, log_loss
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
from tkinter import *
import tkinter as tk
import numpy as np
from PIL import Image, ImageTk
from tkinter import messagebox
master = tk.Tk()
master.geometry("1000x1000")
master.title("WINE QUALITY PREDICTION")
Image = Image.open("wiine1.jpg")
photo = ImageTk.PhotoImage(Image)
mylabel = Label(image=photo).place(x=0, y=0)
resultLabel = Label(master, text="",width=35, font=('italic', 20, 'italic'))
resultLabel.place(x=700, y=900)


def showQuality():
    new = np.array([[float(txt1.get()), float(txt2.get()), float(txt3.get()), float(txt4.get()), float(txt5.get()), float(
        txt6.get()), float(txt7.get()), float(txt8.get()), float(txt9.get()), float(txt10.get()), float(txt11.get())]])
    Ans = RF_clf.predict(new)
    fin = str(Ans)[1:-1]  # IT WILL remove[ ]
    txt12.insert(0, fin)
    print(txt12.get())
    if(int(txt12.get()) == 9):
        #Label(master,text="QUALITY OF WINE IS REALLY GOOD",font=('italic',20,'italic')).place(x=700,y=900)
        resultLabel.config(text="QUALITY OF WINE IS REALLY GOOD")
    elif(int(txt12.get()) == 8):
        # Label(master,text="",font=('italic',20,'italic')).place(x=700,y=900)
        resultLabel.config(text="QUALITY   OF   WINE   IS  GOOD")
    elif(int(txt12.get()) == 7):
        #Label(master,text="QUALITY   OF   WINE   IS  GOOD",font=('italic',20,'italic')).place(x=700,y=900)
        resultLabel.config(text="QUALITY   OF   WINE   IS  GOOD")
    elif(int(txt12.get()) == 6):
      # Label(master,text="QUALITY   OF   WINE   IS  GOOD",font=('italic',20,'italic')).place(x=700,y=900)
        resultLabel.config(text="QUALITY   OF   WINE   IS  GOOD")
    elif(int(txt12.get()) == 5):
        #Label(master,text="QUALITY  OF WINE  IS   MODERATE",font=('italic',20,'italic')).place(x=700,y=900)
        resultLabel.config(text="QUALITY  OF WINE  IS   MODERATE")
    elif(int(txt12.get()) == 4):
        #Label(master,text="QUALITY OF  WINE   IS   AVERAGE",font=('italic',20,'italic')).place(x=700,y=900)
        resultLabel.config(text="QUALITY  OF WINE  IS   AVERAGE")
    elif(int(txt12.get()) == 3):
      #  Label(master,text="QUALITY OF WINE IS REALLY  LOWW",font=('italic',20,'italic')).place(x=700,y=900)
        resultLabel.config(text="QUALITY  OF WINE  IS   LOWW")
    else:
        # Label(master,text="TRY     AGAIN    NEXT     TIME ",font=('italic',20,'italic')).place(x=700,y=900)
        resultLabel.config(text="TRY     AGAIN    NEXT     TIME ")


def delete():
    txt1.delete(0, END)
    txt2.delete(0, END)
    txt3.delete(0, END)
    txt4.delete(0, END)
    txt5.delete(0, END)
    txt6.delete(0, END)
    txt7.delete(0, END)
    txt8.delete(0, END)
    txt9.delete(0, END)
    txt10.delete(0, END)
    txt11.delete(0, END)
    txt12.delete(0, END)
    resultLabel.config(text="")


# ------------------------------------------------------------------------

# For this kernel, I amm only using the red wine dataset
#data = pd.read_csv('winequality-red.csv')
# data.head()

traindata = pd.read_csv('train.csv')
testdata = pd.read_csv('test.csv')

y_train = traindata.quality                  # set 'quality' as target
X_train = traindata.drop('quality', axis=1)

y_test = traindata.quality                  # set 'quality' as target
X_test = traindata.drop('quality', axis=1)

# Summary statistics
traindata.describe()
testdata.describe()

# All columns has the same number of data points
extra = traindata[traindata.duplicated()]
extra.shape
extra1 = testdata[testdata.duplicated()]
extra1.shape

# Let's proceed to separate 'quality' as the target variable and the rest as features.
y_train = traindata.quality                  # set 'quality' as target
X_train = traindata.drop('quality', axis=1)

y_test = testdata.quality                  # set 'quality' as target
X_test = testdata.drop('quality', axis=1)

# print(y_train.shape, X_train.shape)
# print(y_test.shape, X_test.shape)

# Let's look at the correlation among the variables using Correlation chart
colormap = plt.cm.viridis
plt.figure(figsize=(12, 12))
plt.title('Correlation of Features', y=1.05, size=15)
sns.heatmap(traindata.astype(float).corr(), linewidths=0.1, vmax=1.0, square=True,
            linecolor='white', annot=True)
sns.heatmap(testdata.astype(float).corr(), linewidths=0.1, vmax=1.0, square=True,
            linecolor='white', annot=True)

# Use Random Forest Classifier to train a prediction model


# Split data into training and test datasets
seed = 8  # set seed for reproducibility
#X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,random_state=seed)

# Train and evaluate the Random Forest Classifier with Cross Validation
# Instantiate the Random Forest Classifier
RF_clf = RandomForestClassifier(random_state=seed)


# Compute k-fold cross validation on training dataset and see mean accuracy score
cv_scores = cross_val_score(
    RF_clf, X_train, y_train, cv=10, scoring='accuracy')

# Perform predictions
RF_clf.fit(X_train, y_train)
pred_RF = RF_clf.predict(X_test)

#trainset = pd.concat([X_train, y_train], axis=1)
# trainset.to_csv('train.csv')

#trainset = pd.concat([X_test, y_test], axis=1)
# trainset.to_csv('test.csv')

print("accuracy of the model:{0}%".format(accuracy_score(y_test, pred_RF)*100))


# ------------------------------------------------------------------------

Label(master, text="Fixed Acidity", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=150)
Label(master, text="Volatile Acidity", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=200)
Label(master, text="Citric Acid", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=250)
Label(master, text="Residual Sugar", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=300)
Label(master, text="Chlorides", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=350)
Label(master, text="Sulfur Dioxide", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=400)
Label(master, text="Total Sulfur Dioxide", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=450)
Label(master, text="Density", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=500)
Label(master, text="pH", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=550)
Label(master, text="Sulphates", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=600)
Label(master, text="Alcohol", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=650)
Label(master, text="Quality", anchor="nw", font=(
    'italic', 20, 'italic'), width=15).place(x=250, y=850)

txt1 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt1.place(x=700, y=150)
txt2 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt2.place(x=700, y=200)
txt3 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt3.place(x=700, y=250)
txt4 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt4.place(x=700, y=300)
txt5 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt5.place(x=700, y=350)
txt6 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt6.place(x=700, y=400)
txt7 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt7.place(x=700, y=450)
txt8 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt8.place(x=700, y=500)
txt9 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt9.place(x=700, y=550)
txt10 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt10.place(x=700, y=600)
txt11 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt11.place(x=700, y=650)
txt12 = tk.Entry(master, width=15, font=('italic', 20, 'italic'))
txt12.place(x=700, y=850)


Button(master, text='Clear', command=delete, width=15, font=(
    'italic', 20, 'italic'), anchor="nw").place(x=100, y=750)
Button(master, text='Find Quality', command=showQuality, width=15,
       font=('italic', 20, 'italic'), anchor="nw").place(x=500, y=750)
#Button(master, text='Project By',width=15,font=('italic',20,'italic'),anchor="nw").place(x=200, y=850)
#Button(master, text='LARA',width=15,font=('italic',20,'italic'),anchor="nw").place(x=700, y=850)


master.mainloop()
